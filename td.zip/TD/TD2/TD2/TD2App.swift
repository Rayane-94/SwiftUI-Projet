//
//  TD2App.swift
//  TD2
//
//  Created by goldorak on 12/09/2023.
//

import SwiftUI

@main
struct TD2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
