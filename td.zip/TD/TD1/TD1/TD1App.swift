//
//  TD1App.swift
//  TD1
//
//  Created by goldorak on 12/09/2023.
//

import SwiftUI

@main
struct TD1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
